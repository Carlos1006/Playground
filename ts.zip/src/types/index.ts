export type Color = [number, number, number];
