export const R = 0;
export const G = 1;
export const B = 2;