import SusbcribeButton from '../components/subscribeButton';
import css from '../styles/page.module.scss';

const Page_03 = () => {

  return <>
    <div className={`${css.page}`}>
      <SusbcribeButton />
    </div>
  </>
}


export default Page_03;
