import DeleteFile from '../components/deleteFile';
import css from '../styles/page.module.scss';

const Page_03 = () => {

  return <>
    <div className={css.page}>
      <DeleteFile />
    </div>
  </>
}


export default Page_03;
