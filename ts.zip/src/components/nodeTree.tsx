import {
  FC,
  createContext,
  useContext,
  useEffect,
  CSSProperties,
  useState,
  useRef,
} from "react";
import css from "./../styles/nodeTree.module.scss";
const nodeWidth: number = css.nodeWidth as unknown as number;

interface NodeComponentProps {
  name: string;
  level?: number;
  nodes: NodeComponentProps[];
  defaultOpen?: boolean;
  style?: CSSProperties;
  propagatedOpen?: boolean | null;
  parentOffset?: Offset;
  siblings?: number;
  index?: number;
}

interface RowComponentProps {
  level: number;
  nodes: NodeComponentProps[];
  open: boolean;
  parentOffset?: Offset;
}

interface Offset {
  left: number;
  top: number;
}

interface NodeTreeContextProps {
  triggerOffset: number;
  setTriggerOffset: (value: number) => void;
}

const NodeTreeContext = createContext<NodeTreeContextProps>({
  triggerOffset: 0,
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  setTriggerOffset: () => {},
});

const NodeTree: FC = () => {
  const [triggerOffset, setTriggerOffset] = useState<number>(0);
  const nodeTree: NodeComponentProps[] = [
    {
      name: "node1",
      nodes: [
        { name: "node4", nodes: [] },
        { name: "node5", nodes: [] },
        { name: "node6", nodes: [] },
        { name: "node7", nodes: [] },
      ],
    },
    { name: "node2", nodes: [] },
    {
      name: "node3",
      nodes: [
        { name: "node8", nodes: [] },
        { name: "node9", nodes: [] },
        {
          name: "node10",
          nodes: [
            { name: "node12", nodes: [] },
            { name: "node13", nodes: [] },
            { name: "node14", nodes: [] },
          ],
        },
        { name: "node11", nodes: [] },
      ],
    },
  ];

  const contextValue: NodeTreeContextProps = {
    triggerOffset,
    setTriggerOffset,
  };

  return (
    <>
      <NodeTreeContext.Provider value={contextValue}>
        <div className={css.nodeTree}>
          <Node
            name="root"
            level={0}
            nodes={nodeTree}
            defaultOpen={false}
            siblings={nodeTree.length}
            index={0}
          />
        </div>
      </NodeTreeContext.Provider>
    </>
  );
};

const Node: FC<NodeComponentProps> = ({
  name,
  level,
  nodes,
  style = {},
  defaultOpen = false,
  propagatedOpen = null,
  parentOffset = { left: 0, top: 0 },
  siblings = 1,
  index = -1,
}: NodeComponentProps) => {
  const { triggerOffset, setTriggerOffset } = useContext(NodeTreeContext);
  const [open, setOpen] = useState<boolean>(defaultOpen);
  const onClick = () => {
    setOpen((prev) => !prev);
    setTriggerOffset(Math.random());
  };
  const ref = useRef<HTMLDivElement>(null);
  const timeout = useRef<number>(-1);
  const [offset, setOffset] = useState<Offset>({
    left: 0,
    top: 0,
  });

  const getOffset = () => {
    if (ref.current) {
      const { left, top } = ref.current.getBoundingClientRect();
      setOffset({ left, top });
    }
  };

  useEffect(() => {
    if (propagatedOpen !== null && !propagatedOpen) {
      setOpen(false);
      setTriggerOffset(Math.random());
    }
  }, [propagatedOpen]);

  useEffect(() => {
    getOffset();
    window.addEventListener("resize", getOffset);
    return () => window.removeEventListener("resize", getOffset);
  }, [ref]);

  useEffect(() => {
    clearTimeout(timeout.current);
    timeout.current = window.setTimeout(() => {
      getOffset();
    }, 500);
    return () => {
      clearTimeout(timeout.current);
    };
  }, [triggerOffset]);

  return (
    <>
      <div className={css.nodeContainer} style={style}>
        {level !== 0 && (
          <>
            <div
              style={{
                [index === 0 ? "right" : "left"]: 0,
                ...((index as number) > 0 && index < siblings - 1
                  ? { width: "100%" }
                  : {}),
              }}
              className={css.nodeConnector}
            ></div>
          </>
        )}
        {/* ------------------------------------------------------------ */}
        <div ref={ref} className={css.node} onClick={onClick}>
          {level !== 0 && <div className={css.topNodeLine} />}
          <div className={css.notification}>
            <span>10</span>
          </div>
          <div className={css.body}>
            <div className={css.flag} />
            <span>
              {name} {level}
            </span>
            <div className={css.grid} />
          </div>
          {nodes.length > 0 && open && <div className={css.bottomNodeLine} />}
        </div>
        {/* ------------------------------------------------------------ */}
        {nodes.length > 0 && (
          <>
            <Row
              level={(level as number) + 1}
              nodes={nodes}
              open={open}
              parentOffset={offset}
            />
          </>
        )}
      </div>
    </>
  );
};

const Row: FC<RowComponentProps> = ({
  level,
  nodes,
  open,
  parentOffset = { left: 0, top: 0 },
}: RowComponentProps) => {
  const valueToOpen = `calc(-${nodes.length * nodeWidth}px - ${
    nodes.length * 2
  }vw - 0.3vw)`;

  const style: CSSProperties = {
    marginLeft: open ? 0 : valueToOpen,
  };

  const rowStyle: CSSProperties = {
    opacity: open ? 1 : 0,
    marginTop: open ? 0 : "-63px",
  };
  return (
    <>
      <div className={css.row} style={rowStyle}>
        {nodes.map((node, index, array) => (
          <Node
            key={index}
            index={index}
            siblings={array.length}
            style={index === nodes.length - 1 ? style : {}}
            name={node.name}
            level={level}
            nodes={node.nodes}
            propagatedOpen={open}
            parentOffset={parentOffset}
          />
        ))}
      </div>
    </>
  );
};

export default NodeTree;
